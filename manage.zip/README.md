# tenakata-project

### How to run it on your local machine
###### Git clone *project url*
##### In your terminal:-

###### virtualenv venv 
###### source venv/bin/activate
###### cd eboard
###### pip install requirements.txt
###### django mm (makemigrations)
###### django m (migrate)
###### django csu (create superuser)
###### django r (start server)
